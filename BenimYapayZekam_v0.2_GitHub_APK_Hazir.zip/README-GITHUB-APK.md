# Benim Yapay Zekâm — GitHub APK build

Bu proje GitHub Actions ile bulutta APK derlemek için hazırlanmıştır.

1. GitHub'da yeni bir repository oluştur.
2. Bu ZIP'in içindeki proje dosyalarını repository'ye yükle.
3. Actions sekmesinden "Build Android APK" iş akışını çalıştır.
4. İşlem bitince Actions çalışmasının Artifacts bölümünden `BenimYapayZekam-debug` dosyasını indir.
5. ZIP içindeki `app-debug.apk` dosyasını Galaxy A17'ye kur.

Not: Debug APK test amaçlıdır. Google Play'e yayınlamak için ayrı release signing gerekir.

AI bağlantısı için uygulama içindeki Ayarlar > API anahtarı bölümünü kullan.
API anahtarını GitHub'a, ZIP'e veya ekran görüntüsüne koyma.
