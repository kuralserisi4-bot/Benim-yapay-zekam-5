package com.benimyapayzekam.app

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var chat: TextView
    private lateinit var status: TextView
    private lateinit var input: EditText
    private val prefs by lazy { getSharedPreferences("ai", MODE_PRIVATE) }
    private val executor = Executors.newSingleThreadExecutor()

    private val defaultRules = """Sen kullanıcının kişisel yapay zekâ yardımcısısın.
Türkçe konuş. Samimi, açık ve anlaşılır ol.
Kullanıcının kalıcı hafızasına yeni bilgi eklemeden önce mutlaka izin iste.
Kendi çalışma kurallarını veya yönetici ayarlarını kullanıcı onayı olmadan değiştirme.
Kullanıcının belirlediği kişilik ve davranış kurallarına uy."""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        chat = findViewById(R.id.chat)
        status = findViewById(R.id.status)
        input = findViewById(R.id.input)

        chat.text = "Merhaba. Ben senin kişisel yapay zekânım.\n\nÖnce Ayarlar'dan API anahtarını ekle."
        updateStatus()

        findViewById<Button>(R.id.send).setOnClickListener { sendMessage() }
        findViewById<Button>(R.id.settings).setOnClickListener { settingsDialog() }
    }

    private fun updateStatus() {
        status.text = if (prefs.getString("api_key", "").orEmpty().isBlank())
            "AI bağlantısı: API anahtarı bekleniyor"
        else "AI bağlantısı: hazır • Öğrenme: sadece sen onaylarsan"
    }

    private fun sendMessage() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        val key = prefs.getString("api_key", "").orEmpty()
        if (key.isBlank()) {
            Toast.makeText(this, "Önce Ayarlar > API anahtarı bölümünden anahtar ekle.", Toast.LENGTH_LONG).show()
            return
        }

        chat.append("\n\nSen: $text\nAI: düşünüyor...")
        input.text.clear()
        findViewById<Button>(R.id.send).isEnabled = false

        executor.execute {
            val result = callOpenAI(key, text)
            runOnUiThread {
                // Replace the temporary suffix.
                val current = chat.text.toString()
                val cleaned = current.substringBeforeLast("\nAI: düşünüyor...")
                chat.text = cleaned + "\nAI: " + result
                findViewById<Button>(R.id.send).isEnabled = true
            }
        }
    }

    private fun callOpenAI(key: String, userText: String): String {
        return try {
            val url = URL("https://api.openai.com/v1/responses")
            val conn = (url.openConnection() as HttpURLConnection)
            conn.requestMethod = "POST"
            conn.setRequestProperty("Authorization", "Bearer $key")
            conn.setRequestProperty("Content-Type", "application/json")
            conn.connectTimeout = 20000
            conn.readTimeout = 60000
            conn.doOutput = true

            val body = JSONObject().apply {
                put("model", "gpt-5.6")
                put("instructions", prefs.getString("rules", defaultRules))
                put("input", userText)
            }.toString()

            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            val response = stream.bufferedReader().use { it.readText() }
            if (conn.responseCode !in 200..299) {
                return "API hatası (${conn.responseCode}). Ayarlardaki anahtarı ve API hesabını kontrol et."
            }

            val json = JSONObject(response)
            extractOutputText(json)
        } catch (e: Exception) {
            "Bağlantı hatası: ${e.message ?: "bilinmeyen hata"}"
        }
    }

    private fun extractOutputText(json: JSONObject): String {
        val output = json.optJSONArray("output") ?: return "Yanıt alınamadı."
        val parts = mutableListOf<String>()
        for (i in 0 until output.length()) {
            val item = output.optJSONObject(i) ?: continue
            val content = item.optJSONArray("content") ?: continue
            for (j in 0 until content.length()) {
                val c = content.optJSONObject(j) ?: continue
                val text = c.optString("text")
                if (text.isNotBlank()) parts.add(text)
            }
        }
        return parts.joinToString("\n").ifBlank { "Yanıt metni bulunamadı." }
    }

    private fun settingsDialog() {
        val options = arrayOf("API anahtarı", "Kişilik / davranış kuralları", "Öğrenme izni")
        AlertDialog.Builder(this).setTitle("Yönetici Paneli").setItems(options) { _, which ->
            when (which) {
                0 -> apiKeyDialog()
                1 -> rulesDialog()
                2 -> {
                    Toast.makeText(this, "Kural: AI kalıcı hafızaya yalnızca sen onay verirsen ekleme yapacak.", Toast.LENGTH_LONG).show()
                }
            }
        }.show()
    }

    private fun apiKeyDialog() {
        val edit = EditText(this)
        edit.hint = "sk-..."
        edit.setSingleLine()
        edit.setText(prefs.getString("api_key", ""))
        AlertDialog.Builder(this).setTitle("OpenAI API anahtarı")
            .setMessage("Anahtar yalnızca bu telefonun uygulama depolamasında tutulur. Paylaşma veya ekran görüntüsünde gösterme.")
            .setView(edit)
            .setPositiveButton("Kaydet") { _, _ ->
                prefs.edit().putString("api_key", edit.text.toString().trim()).apply()
                updateStatus()
            }
            .setNegativeButton("İptal", null).show()
    }

    private fun rulesDialog() {
        val edit = EditText(this)
        edit.setText(prefs.getString("rules", defaultRules))
        edit.minLines = 8
        edit.gravity = android.view.Gravity.TOP
        AlertDialog.Builder(this).setTitle("Kişilik ve davranış kuralları")
            .setView(edit)
            .setPositiveButton("Kaydet") { _, _ ->
                prefs.edit().putString("rules", edit.text.toString()).apply()
            }
            .setNegativeButton("İptal", null).show()
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
